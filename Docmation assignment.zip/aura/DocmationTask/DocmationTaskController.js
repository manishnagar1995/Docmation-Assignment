({
	doInit : function(component, event, helper) {
		helper.getContactlist(component, event);
        var  listcon = component.get('v.ContactList');
        listcon.push({
              'sobjectType': 'Contact',
            'FirstName': '',
            'LastName': '',
            'Email':'',
            'AccountName': '',
            'AccountId':''
        });
        component.set("v.ContactList",listcon);
        component.set('v.columns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Email', fieldName: 'Email', type: 'text'},
            {label: 'Account Name', fieldName: 'AccountName', type: 'text'}
        ]);
	},
    addRow: function(component, event, helper) {
        helper.addContactRecord(component, event);
    },
      save: function(component, event, helper) {
       // if (helper.validateAccountList(component, event)) {
            helper.saveContactList(component, event);
      //  }
    },
    
      handleComponentEvent :  function(component,event,helper){ 
          var valueFromChild = event.getParam("varlookup");
        //    component.find("auraid").set("v.value", "Find Example");
      // component.set("v.ContactList.contact.Account.Name",valueFromChild.text);
       component.set("v.ContactList.AccountId",valueFromChild.val);
     
       
    },
})