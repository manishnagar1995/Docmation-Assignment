({
    
    getContactlist :function(component, event) {
        var action = component.get("c.getContacts");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var conlist = [];
            var state = response.getState();
            if (state === "SUCCESS") {
                var rows = response.getReturnValue();
                for (var i = 0; i < rows.length; i++) {
                    var row = rows[i];
                    if (row.Account) row.AccountName = row.Account.Name;
                }
                component.set("v.ContactRecordList", rows);
            }
        });
        $A.enqueueAction(action);
        
    },
    
    addContactRecord: function(component, event) {
        var conList = component.get("v.ContactList");
        //Add New Account Record
        conList.push({
            'sobjectType': 'Contact',
            'FirstName': '',
            'LastName': '',
            'Email':'',
            'AccountName': '',
            'AccountId':''
        });
        component.set("v.ContactList", conList);
    },
    
    
    
    saveContactList: function(component, event, helper) {
        var conrecordlist = component.get("v.ContactList");
        // console.log('========'+ JSON.stringify(conrecordlist));
        var finalconlist = [];
        var varboolean =false;
        for(var i = 0 ; i < conrecordlist.length ; i++ ){
            
            finalconlist.push({
                'sobjectType': 'Contact',
                'FirstName': conrecordlist[i].FirstName,
                'LastName': conrecordlist[i].LastName,
                'Email':conrecordlist[i].Email,
                'AccountId':conrecordlist[i].AccountId.val
            });
            
            
            
        }
        
       /* for(var i= 0 ; i < finalconlist.length ; i++ ){
            for(var j = 1 ; j < finalconlist.length ; j++ ){
                if(finalconlist[i].AccountId == finalconlist[j].AccountId){
                    if(finalconlist[i].Email == finalconlist[j].Email){
                        varboolean = true;
                          alert("Email validation ", finalconlist[i].Email +'is Duplicate Email for'+ finalconlist[j].AccountId); 
                        component.set("v.ErrorEmail",finalconlist[i].Email);
                       var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "error!",
                            "message": finalconlist[i].Email +'is duplicate for'+ finalconlist[i].LastName
                        });
                        toastEvent.fire();
                    }
                }
            }
        }*/
         
         
        console.log('========'+ JSON.stringify(finalconlist));
        var action = component.get("c.saveContact");
        action.setParams({
            "conList": finalconlist
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                var rows = response.getReturnValue();
                
        console.log('========'+ JSON.stringify(rows[0]));
                if(!rows[0].error){
                    component.set("v.ContactList", null);
                   console.log('con========'+ JSON.stringify(rows[0].con)); 
                    for (var i = 0; i < rows[0].con.length; i++) {
                        var row = rows[0].con[i];
                       console.log('con========'+ JSON.stringify(row)); 
                        if (row.Account) row.AccountName = row.Account.Name;
                    }
                    component.set("v.ContactRecordList", rows[0].con);
                }else{
                    alert("email validation");
                }
                
            }
        }); 
        $A.enqueueAction(action);
        
        
    },
})